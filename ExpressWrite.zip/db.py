str = "database"
print(str)